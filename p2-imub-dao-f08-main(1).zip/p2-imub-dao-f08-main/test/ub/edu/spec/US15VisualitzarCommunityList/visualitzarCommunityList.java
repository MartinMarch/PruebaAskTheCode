package ub.edu.spec.US15VisualitzarCommunityList;

import org.concordion.api.BeforeExample;
import org.concordion.integration.junit4.ConcordionRunner;
import org.junit.runner.RunWith;
import ub.edu.controller.Controller;
import ub.edu.model.ImUBException;

import java.util.ArrayList;
import java.util.List;

@RunWith(ConcordionRunner.class)
public class visualitzarCommunityList {
    private Controller controlador;
    @BeforeExample
    private void init() {
        try {
            controlador = Controller.getInstance();
            controlador.init();
        } catch (ImUBException e) {
            System.out.println(e.getMessage()); // TODO: ver qpdo con esto
        }
    }

    public void initComunitatsClient(){
        String client = "rick@gmail.com";
        try {
            controlador.afegirseComunitat(client, "Tacos de sal");
            controlador.afegirseComunitat(client, "Equipo Alfa Buena Dinamita Onda Escuadron Lobo");
            controlador.afegirseComunitat(client, "Los 4 fantásticos");
            controlador.afegirseComunitat(client, "Detectives de bajo presupuesto");
            controlador.afegirseComunitat(client, "Aqui no apoyamos al pintor austriaco de bigote chistoso");
        } catch (ImUBException e) {
            System.out.println(e.getMessage()); // TODO: ver qpdo con esto
        }
    }

    public Iterable<String> visualitzarCommunityList(String client, String nomComunitat) {
        try {
            return controlador.visualitzarCommunityList(client, nomComunitat);
        } catch (ImUBException e) {
            List<String> errorList = new ArrayList<>();
            errorList.add(e.getMessage());
            return errorList;
        }
    }
}
