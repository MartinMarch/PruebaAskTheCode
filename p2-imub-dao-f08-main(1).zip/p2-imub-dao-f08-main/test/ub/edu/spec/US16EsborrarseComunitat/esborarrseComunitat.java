package ub.edu.spec.US16EsborrarseComunitat;

import org.concordion.api.BeforeExample;
import org.concordion.integration.junit4.ConcordionRunner;
import org.junit.runner.RunWith;
import ub.edu.controller.Controller;
import ub.edu.model.ImUBException;

@RunWith(ConcordionRunner.class)
public class esborarrseComunitat {
    private Controller controlador;
    @BeforeExample
    private void init() {
        try {
            controlador = Controller.getInstance();
            controlador.init();
        } catch (ImUBException e) {
            System.out.println(e.getMessage()); // TODO: ver qpdo con esto
        }
    }
    public void afegirComunitats() {
        controlador.afegirComunitat("Tacos de sal", "Contenido principalmente de accion");
        controlador.afegirComunitat("Equipo Alfa Buena Dinamita Onda Escuadron Lobo", "Puro contenido del bueno");
        controlador.afegirComunitat("Los 4 fantásticos", "Contenido de superhéroes");
        controlador.afegirComunitat("Detectives de bajo presupuesto", "Contenido tipo policíaco y de crimenes para todas las edades");
        controlador.afegirComunitat("Wannabes prota de comedias romanticas", "Todo el contenido romantico que puedas digerir");
        controlador.afegirComunitat("Aqui no apoyamos al pintor austriaco de bigote chistoso", "Contenido de guerra y de historia");
    }

    public void initComunitatsClient(){
        String client = "rick@gmail.com";
        try {
            controlador.afegirseComunitat(client, "Tacos de sal");
            controlador.afegirseComunitat(client, "Equipo Alfa Buena Dinamita Onda Escuadron Lobo");
            controlador.afegirseComunitat(client, "Los 4 fantásticos");
            controlador.afegirseComunitat(client, "Detectives de bajo presupuesto");
            controlador.afegirseComunitat(client, "Aqui no apoyamos al pintor austriaco de bigote chistoso");
        } catch (ImUBException e) {
            //Solo para depuracion
            System.out.println(e.getMessage()); // TODO: ver qpdo con esto
        }
    }

    public String esborrarseDeComunitat(String client, String nomComunitat) {
        try {
            return controlador.esborrarseComunitat(client, nomComunitat);
        } catch (ImUBException e) {
            return e.getMessage();
        }
    }

}
