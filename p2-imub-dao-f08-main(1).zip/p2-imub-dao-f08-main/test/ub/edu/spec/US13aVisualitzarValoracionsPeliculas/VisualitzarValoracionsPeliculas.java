package ub.edu.spec.US13aVisualitzarValoracionsPeliculas;
import org.concordion.api.BeforeExample;
import org.concordion.integration.junit4.ConcordionRunner;
import org.junit.runner.RunWith;
import ub.edu.controller.Controller;
import ub.edu.model.ImUBException;

@RunWith(ConcordionRunner.class)
public class VisualitzarValoracionsPeliculas {
    private Controller controlador;
    @BeforeExample
    private void init() {
        try {
            controlador = Controller.getInstance();
            controlador.init();
        } catch (ImUBException e) {
            System.out.println(e.getMessage()); // TODO: ver qpdo con esto
        }
    }

    public String valorar(String nomPeli, String client, int puntuacion){
        return controlador.valorarPelicula(nomPeli, client, puntuacion, "Numerica");
    }
    public String visualitzarValoracionsPeliculas(String nomPeli) {
        return controlador.visualitzarValoracioPelicula(nomPeli, "Numerica","Usuaris");
    }
}
