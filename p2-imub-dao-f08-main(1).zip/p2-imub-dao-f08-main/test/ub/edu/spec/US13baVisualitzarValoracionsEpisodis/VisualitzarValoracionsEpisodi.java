package ub.edu.spec.US13baVisualitzarValoracionsEpisodis;
import org.concordion.api.BeforeExample;
import org.concordion.integration.junit4.ConcordionRunner;
import org.junit.runner.RunWith;
import ub.edu.controller.Controller;
import ub.edu.model.ImUBException;

@RunWith(ConcordionRunner.class)
public class VisualitzarValoracionsEpisodi {
    private Controller controlador;
    @BeforeExample
    private void init() {
        try {
            controlador = Controller.getInstance();
            controlador.init();
        } catch (ImUBException e) {
            System.out.println(e.getMessage()); // TODO: ver qpdo con esto
        }
    }

    public String valorar(String serie, int temporada, int episodi, String client, int puntuacio){
        return controlador.valorarEpisodio(serie, temporada, episodi, client, puntuacio,"Numerica");
    }
    public String visualitzarValoracionsEpisodi(String serie, int temporada, int episodi) {
        return controlador.visualitzarValoracio(serie, temporada, episodi, "Numerica", "Usuaris");
    }
}
