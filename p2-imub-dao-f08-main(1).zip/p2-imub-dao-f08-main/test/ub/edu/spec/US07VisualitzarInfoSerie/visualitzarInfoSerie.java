package ub.edu.spec.US07VisualitzarInfoSerie;

public class visualitzarInfoSerie {
}
