package ub.edu.spec.US06VisualitzarInfoPelicula;

public class visualitzarInfoPelicula {
}
