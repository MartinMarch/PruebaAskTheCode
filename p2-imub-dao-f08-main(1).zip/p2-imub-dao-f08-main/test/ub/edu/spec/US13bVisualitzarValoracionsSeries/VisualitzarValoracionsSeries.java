package ub.edu.spec.US13bVisualitzarValoracionsSeries;
import org.concordion.api.BeforeExample;
import org.concordion.integration.junit4.ConcordionRunner;
import org.junit.runner.RunWith;
import ub.edu.controller.Controller;
import ub.edu.model.ImUBException;

@RunWith(ConcordionRunner.class)
public class VisualitzarValoracionsSeries {
    private Controller controlador;
    @BeforeExample
    private void init() {
        try {
            controlador = Controller.getInstance();
            controlador.init();
        } catch (ImUBException e) {
            System.out.println(e.getMessage()); // TODO: ver qpdo con esto
        }
    }

    public String valorar(String serie, int temporada, int episodi, String client, int puntuacio, String tipusValoracio){
        return controlador.valorarEpisodio(serie, temporada, episodi, client, puntuacio, tipusValoracio);
    }
    public String visualitzarValoracionsSerie(String serie) {
        return controlador.visualitzarValoracio(serie, "Numerica", "Usuaris");
    }
}
