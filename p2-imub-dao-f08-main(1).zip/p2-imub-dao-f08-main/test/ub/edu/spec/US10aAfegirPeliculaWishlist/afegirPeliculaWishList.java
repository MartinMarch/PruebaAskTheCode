package ub.edu.spec.US10aAfegirPeliculaWishlist;

import org.concordion.api.BeforeExample;
import org.concordion.integration.junit4.ConcordionRunner;
import org.junit.runner.RunWith;
import ub.edu.controller.Controller;
import ub.edu.model.ImUBException;

@RunWith(ConcordionRunner.class)
public class afegirPeliculaWishList {
    private Controller controlador;

    @BeforeExample
    private void init() {
        try {
            controlador = Controller.getInstance();
            controlador.init();
        } catch (ImUBException e) {
            System.out.println(e.getMessage()); // TODO: ver qpdo con esto
        }
    }


    public void initWishList() {
        String client = "rick@gmail.com";
        try {
            controlador.afegirContingutWishList("Barbie", client);
            controlador.afegirContingutWishList("El Padrino", client);
            controlador.afegirContingutWishList("El Padrino 2", client);
        } catch (ImUBException e) {
            System.out.println(e.getMessage()); // TODO: ver qpdo con esto
        }
    }

    public String afegirPelicula(String nomPelicula, String client) {
        try {
            return controlador.afegirContingutWishList(nomPelicula, client);
        } catch (ImUBException e) {
            return e.getMessage();
        }
    }
}
