package ub.edu.spec.US04VisualitzarTemporades;

import org.concordion.api.BeforeExample;
import org.concordion.integration.junit4.ConcordionRunner;
import org.junit.runner.RunWith;
import ub.edu.controller.Controller;
import ub.edu.model.ImUBException;

@RunWith(ConcordionRunner.class)
public class visualitzarTemporades {

    private Controller controlador;

    @BeforeExample
    private void init() {
        try {
            controlador = Controller.getInstance();
            controlador.init();
        } catch (ImUBException e) {
            System.out.println(e.getMessage()); // TODO: ver qpdo con esto
        }
    }

    public Iterable<String> visualitzarTemporadesSerie(String nomSerie) {
        return controlador.visualitzarTemporadesSerie(nomSerie);
    }


}
