package ub.edu.spec.US02Login;

import org.concordion.api.BeforeExample;
import org.concordion.integration.junit4.ConcordionRunner;
import org.junit.runner.RunWith;
import ub.edu.controller.Controller;
import ub.edu.model.ImUBException;

@RunWith(ConcordionRunner.class)
public class loginClient {
    private Controller controlador;

    @BeforeExample
    private void init() {
        try {
            controlador = Controller.getInstance();
            controlador.init();
        } catch (ImUBException e) {
            System.out.println(e.getMessage()); // TODO: ver qpdo con esto
        }
    }

    public String recuperarContrassenya(String user) {
        try {
            return controlador.recuperarContrassenya(user);
        } catch (ImUBException e) {
            return e.getMessage();
        }
    }

    public String loginPersona(String user, String pass) {
        try {
            return controlador.loguejarClient(user, pass);
        } catch (ImUBException e) {
            return e.getMessage();
        }
    }

}
