package ub.edu.controller;

import org.concordion.api.MultiValueResult;

import ub.edu.facade.*;
import ub.edu.model.*;

public class Controller {
    private volatile static Controller instance;

    private ImUB imub;
    private FacadeData initilizer;
    private FacadeClient clientFacade;
    private FacadeContingut contingutFacade;
    private FacadeComunitat comunitatFacade;
    private FacadeValoracio valoracioFacade;

    private Controller() throws ImUBException {
        init();
    }

    /*-----------------------------*/
    /*  Inicializar Controller   */
    /*-----------------------------*/
    public void init() throws ImUBException {
        initEmptyDataStructures();
        loadData();
        // TODO: manejo de excepciones sin que tire throws en el constructor del singleton o en el getInstance
    }
    public void initEmptyDataStructures(){
        imub = new ImUB();
        this.initilizer = new FacadeData(imub);
        this.clientFacade = new FacadeClient(imub);
        this.contingutFacade = new FacadeContingut(imub);
        this.comunitatFacade = new FacadeComunitat(imub);
        this.valoracioFacade = new FacadeValoracio(imub);
    }
    private void loadData() throws ImUBException {
        initilizer.load();
    }

    public static Controller getInstance() throws ImUBException {
        if (instance == null) {
            synchronized (Controller.class) {
                if (instance == null) {
                    instance = new Controller();
                }
            }
        }
        return instance;
    }

    /*-----------------------------*/
    /*  Client  */
    /*-----------------------------*/
    public String loguejarClient(String username, String password) throws ImUBException {

        return clientFacade.loguejarClient(username, password);
    }
    public String recuperarContrassenya(String username) throws ImUBException {
        return clientFacade.recuperarContrassenya(username);
    }
    public String findClient(String username) {
        return clientFacade.findClient(username);
    }

    /*-----------------------------*/
    /*  Validar datos  */
    /*-----------------------------*/
    public String validatePassword(String b) {
        return Validacions.validatePassword(b);
    }
    public String validateUsername(String b) {
        return Validacions.validateUsername(b);
    }
    // Validem la Client a la capa de persistencia i no a memoria, per seguretat en les possibles sincronitzacions
    public String validateRegistreClient(String username, String password) {
        return Validacions.validateRegistreClient(initilizer.getDataService() , username,password);
        // TODO: revisar el tema de dataservice
    }

    /*-----------------------------*/
    /*  Visualitzar Contingut  */
    /*-----------------------------*/
    public Iterable<String> visualitzarPelisPerNom() {
        return contingutFacade.visualitzarPelisPerNom();
    }
    public Iterable<MultiValueResult> visualitzarPelisPerEstrena() {
        return contingutFacade.visualitzarPelisPerEstrena();
    }
    public Iterable<String> visualitzarPelisPerTematica(String nomTematica) {
        return contingutFacade.visualitzarPelisPerTematica(nomTematica);
    }
    public Iterable<String> visualitzarSeriesPerNom() {
        return contingutFacade.visualitzarSeriesPerNom();
    }
    public Iterable<String> visualitzarTemporadesSerie(String nomSerie) {
        return contingutFacade.visualitzarTemporadesSerie(nomSerie);
    }
    public Iterable<String> visualitzaEpisodisTemporadaSerie(String nomSerie, int numTemporada) {
        return contingutFacade.visualitzaEpisodisTemporadaSerie(nomSerie, numTemporada);
    }

    /*-----------------------------*/
    /*  Valorar  */
    /*-----------------------------*/
    /*
    public String valorarPelicula(String nomPeli, String user, int puntuacio) {
        return ImUB.valorarPelicula(nomPeli, user, puntuacio, llistaPelicules, carteraClients);
    }
    public String valorarEpisodio(String serie, int numTemp, int numEpisodio, String user, int puntuacio){
        return ImUB.valorarEpisodi(serie, numTemp, numEpisodio, user, puntuacio, llistaSeries, carteraClients);
    }*/

    /*-----------------------------*/
    /*  Afegir Contingut  */
    /*-----------------------------*/
    public void afegirPelicula(String nom, int estrena, int durada) {
        contingutFacade.afegirPelicula(nom, estrena, durada);
    }
    public void afegirSerie(String nomSerie, int anyEstrena) {
        contingutFacade.afegirSerie(nomSerie, anyEstrena);
    }

    public void afegirTemporada(String nomSerie, int numTemporada) throws ImUBException {
        contingutFacade.afegirTemporada(nomSerie, numTemporada);
    }

    public void afegirEpisodi(String nomSerie, int numTemporada, int numEpisodi, String títolEpisodi, int durada) throws ImUBException {
        contingutFacade.afegirEpisodi(nomSerie, numTemporada, numEpisodi, títolEpisodi, durada);
    }

    /*-----------------------------*/
    /*  WishList  */
    /*-----------------------------*/
    public String afegirContingutWishList(String nomContingut, String user) throws ImUBException {
        return clientFacade.afegirContingutWishList(nomContingut, user);
    }
    public String esborrarContingutWishList(String nomContingut, String user) throws ImUBException {
        return clientFacade.esborrarContingutWishList(nomContingut, user);
    }
    public Iterable<String> visualitzarWishList(String user) throws ImUBException {
        return clientFacade.visualitzarWishList(user);
    }

    /*-----------------------------*/
    /*  Comunitats  */
    /*-----------------------------*/
    public void afegirComunitat(String nom, String descripcio){
        comunitatFacade.afegirComunitat(nom, descripcio);
    }
    public String afegirseComunitat(String user, String nomComunitat) throws ImUBException {
        return comunitatFacade.afegirseComunitat(user, nomComunitat);
    }
    public Iterable<String> visualitzarCommunityList(String user, String nomComunitat) throws ImUBException {
        return comunitatFacade.visualitzarCommunityList(user, nomComunitat);
    }
    public String esborrarseComunitat(String user, String nomComunitat) throws ImUBException {
        return comunitatFacade.esborrarseComunitat(user, nomComunitat);
    }


    public String visualitzarValoracioPelicula(String nomPeli, String tipusValoracio, String tipusNumerica) {
        return valoracioFacade.visualitzarValoracioPelicula(nomPeli, tipusValoracio, tipusNumerica);
    }
    public String visualitzarValoracio(String serie, int numTemp, int numEpisodio, String tipusValoracio, String tipusNumerica) {
        return valoracioFacade.visualitzarValoracioEpisodi(serie, numTemp, numEpisodio, tipusValoracio, tipusNumerica);
    }
    public String visualitzarValoracio(String serie, int numTemp, String tipusValoracio, String tipusNumerica) {
        return valoracioFacade.visualitzarValoracioTemporada(serie, numTemp, tipusValoracio, tipusNumerica);
    }
    public String visualitzarValoracio(String serie, String tipusValoracio, String tipusNumerica) {
        return valoracioFacade.visualitzarValoracioSerie(serie, tipusValoracio, tipusNumerica);
    }
    public String valorarPelicula(String nomPeli, String user, int puntuacio, String tipusValoracio){
        return valoracioFacade.valorarPelicula(nomPeli, user, puntuacio, tipusValoracio);
    }


    public String valorarEpisodio(String serie, int numTemp, int numEpisodio, String user, int puntuacio, String tipusValoracio){
        return valoracioFacade.valorarEpisodi(serie, numTemp, numEpisodio, user, puntuacio, tipusValoracio);
    }

    public String visualitzarTop5Pelicules(String tipusValoracio, String tipusNumerica){
        return valoracioFacade.visualitzarTop5Pelicules(tipusValoracio, tipusNumerica);
    }

    public String visualitzarTop5Series(String tipusValoracio, String tipusNumerica){
        return valoracioFacade.visualitzarTop5Series(tipusValoracio, tipusNumerica);
    }
}