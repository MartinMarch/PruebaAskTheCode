package ub.edu.model;

public interface GestorContingut {
    boolean isValorado(String tipus, Client cliente);
    void afegirValoracio(ValoracioClient valoracio);

}
