package ub.edu.model;

public class ValoracioLike extends ValoracioClient{
    private int like;

    public ValoracioLike(int like, Client client){
        super(client);
        this.like = like;
    }

    public int getLikeUnlike() {
        return like;
    }
    public String tipusValoracio() { return "Like"; }

    @Override
    public boolean isValid() {
        return Validacions.validarLike(like);
    }

    @Override
    public String errorMessage() {
        return ("La valoracio ha de ser un 1 per donarli Like o un 0 per donarli unlike");
    }

    @Override
    public String successMessage(String contingut) {
        if(like == 0){
            return ("Li has donat a UnLike a l'/la " + contingut);
        }
        return ("Li has donat a Like a l'/la " + contingut);
    }
    @Override
    public boolean corresponde(String tipus, Client cliente) {
        return (tipus.equals("Like") && cliente.equals(getClient()));
    }
}
