package ub.edu.model;

public class VisualitzarValoracioEpisodi {
    public static String execute(Episodi episodi, String tipusValoracio, String tipusNumerica){
        return "La valoració mitja és de: " + episodi.calcularValoracio(tipusValoracio, tipusNumerica);
    }
}
