package ub.edu.model;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;

public class Pelicula extends ContingutDigital implements Wishable, GestorContingut{

    private String idioma;
    private double valoracioMitja;
    private int anyPrimeraEmissio;
    private int durada;
    private float valoracioInicial;
    private ArrayList<Tematica> llistaTematiques;

    private ArrayList<ValoracioClient> llistaValoraciones;

    public Pelicula(String titol, int estrena, int durada) {
        super(titol, estrena);
        this.durada = durada;
        llistaTematiques = new ArrayList<Tematica>();
        llistaValoraciones = new ArrayList<ValoracioClient>();
    }

    public Pelicula(String titol, String descripcio, String url, int estrena, String idioma, int durada, float valoracioInicial) {
        super(titol, descripcio, estrena, url, idioma);
        this.durada = durada;
        this.valoracioInicial = valoracioInicial;
        llistaTematiques = new ArrayList<Tematica>();
        llistaValoraciones = new ArrayList<ValoracioClient>();
    }

    //Nuevo
    @Override
    public boolean isValorado(String tipus, Client cliente) {
        for (ValoracioClient valoracio : llistaValoraciones) {
            if (valoracio.corresponde(tipus, cliente)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public void afegirValoracio(ValoracioClient valoracio) {
        llistaValoraciones.add(valoracio);
    }


    public double calcularValoracio(String tipus, String tipusNumerica) {
        CalculadoraValoracioStrategy c = FactoryCalculadora.createCalculadora(tipus);
        if (c == null) {
            return 0;
        }
        if (tipus.equals("Numerica")) {
            if(tipusNumerica.equals("Inicial")){
                return c.calcularValoracio(llistaValoraciones, valoracioInicial);
            }
        }
        return c.calcularValoracio(llistaValoraciones);
    }
    @Override
    public String toString() {
        return "Pelicula{" + "nomPelicula='" + getTitol();
    }

}
