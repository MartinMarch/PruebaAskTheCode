package ub.edu.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class GestorWishlist {
    private WishList wishlist;

    public GestorWishlist(WishList wishlist) {
        this.wishlist = wishlist;
    }

    public Iterable<String> visualitzarWishlist() {
        List<String> newWishList = new ArrayList<>();
        if (wishlist.isEmpty()) {
            newWishList.add("No hi ha contingut disponible");
        } else {
            for(Wishable wishable : wishlist.getContingut()){
                newWishList.add(wishable.getTitol());
            }
            Collections.reverse(newWishList);
        }
        return newWishList;
    }

    public String afegirContingut(Wishable contingut) throws ImUBException {
        if (contingut == null){
            throw new ImUBException("Aquest contingut no es troba al sistema");
        } else if (wishlist.contains(contingut)){
            throw new ImUBException("Aquest/a "+ contingut.getClass().getSimpleName() +" ja es troba a la WishList");
        } else {
            wishlist.afegirContingut(contingut);
            return contingut.getClass().getSimpleName() + " agregat/da exitosament";
        }
    }

    public String esborrarContingut(Wishable contingut) throws ImUBException {
        if (contingut == null){
            throw new ImUBException("Aquest contingut no es troba al sistema");
        } else if (!wishlist.contains(contingut)){
            throw new ImUBException ("Aquest/a "+ contingut.getClass().getSimpleName() +" no es troba a la WishList");
        } else {
            wishlist.esborrarContingut(contingut);
            return contingut.getClass().getSimpleName() + " eliminat/da exitosament";
        }
    }
}
