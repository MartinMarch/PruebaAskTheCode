package ub.edu.model;

import org.concordion.api.MultiValueResult;
import ub.edu.resources.dao.Parell;

import java.util.*;

public class ImUB {
    private CarteraClients carteraClients;
    private Map<String, Serie> llistaSeries;
    private Map<String, Pelicula> llistaPelicules;
    private Map<String, Tematica> llistaTemes;
    private Map<String, Comunitat> llistaComunitats;

    public ImUB(){
        initEmptyDataStructures();
    }
    public void initEmptyDataStructures(){
        carteraClients = new CarteraClients();
        llistaSeries = new HashMap<>();
        llistaPelicules = new HashMap<>();
        llistaTemes = new HashMap<>();
        llistaComunitats = new HashMap<>();
    }

    /*-----------------------------*/
    /*  Relacionar contenido  */
    /*-----------------------------*/
    public void relacionarPeliculesTemes(List<Parell<String, String>> relacionsPT) {
        for (Parell p : relacionsPT) {
            Tematica tema = llistaTemes.get(p.getElement1());
            Pelicula peli = llistaPelicules.get(p.getElement2());
            peli.addTematica(tema);
        }
    }
    public void relacionarSeriesTemes(List<Parell<String, String>> relacionsST) {
        for (Parell p : relacionsST) {
            Tematica tema = llistaTemes.get(p.getElement1());
            Serie serie = llistaSeries.get(p.getElement2());
            serie.addTematica(tema);
        }
    }
    public void relacionarComunitatsTemes(List<Parell<String, String>> relacionsCT) throws ImUBException {
        for (Parell p : relacionsCT) {
            Tematica tema = llistaTemes.get(p.getElement1());
            Comunitat comunitat = llistaComunitats.get(p.getElement2());
            comunitat.addTematica(tema);
        }
    }

    /*-----------------------------*/
    /*  Cargar datos  */
    /*-----------------------------*/
    public void loadCarteraClients(List<Client> l) throws ImUBException {
        if (l != null) {
            carteraClients = new CarteraClients(l);
            return;
        }else throw new ImUBException("Error al cargar la cartera de clients");
    }
    public void loadPelicules(List<Pelicula> l) throws ImUBException {
        if (l != null) {
            for (Pelicula p : l) {
                llistaPelicules.put(p.getTitol(), p);
            }
            return;
        }else throw new ImUBException("Error al cargar la llista de pelicules");
    }
    public void loadSeries(List<Serie> l) throws ImUBException {
        if (l != null) {
            for (Serie s : l) {
                llistaSeries.put(s.getTitol(), s);
            }
            return;
        }else throw new ImUBException("Error al cargar la llista de series");
    }
    public void loadTematiques(List<Tematica> l) throws ImUBException {
        if (l != null) {
            for (Tematica t : l) {
                llistaTemes.put(t.getNomTematica(), t);
            }
            return;
        }else throw new ImUBException("Error al cargar la llista de tematiques");
    }
    public void loadComunitats(List<Comunitat> l) throws ImUBException {
        if (l != null) {
            for (Comunitat c : l) {
                llistaComunitats.put(c.getNom(), c);
            }
            return;
        }else throw new ImUBException("Error al cargar la llista de comunitats");
    }

    /*-----------------------------*/
    /*  Cliente  */
    /*-----------------------------*/
    public String findClient(String username) {
        Client client = carteraClients.find(username);
        if (client != null) return "Client ja existent en el Sistema";
        else return "Client desconeguda";
    }
    public String loguejarClient(String username, String password) throws ImUBException {
        Client client = carteraClients.find(username);
        if (client == null) {
            throw new ImUBException("Correu inexistent");
        }
        if (client.getPwd().equals(password)) {
            return "Login correcte";
        } else {
            throw new ImUBException("Contrassenya incorrecta");
        }
    }
    public String recuperarContrassenya(String username) throws ImUBException {
        Client client = carteraClients.find(username);
        if (client == null) {
            throw new ImUBException("Correu inexistent");
        }
        return client.getPwd();
    }
    public Client getClient(String username) throws ImUBException {
        Client client = carteraClients.find(username);
        if (client == null) {
            throw new ImUBException("Client inexistent");
        }
        return client;
    }

    /*-----------------------------*/
    /*  Visualitzar Contingut  */
    /*-----------------------------*/
    //Peliculas
    public Iterable<String> visualitzarPelisPerNom() {
        SortedSet<String> pelisDisponibles = new TreeSet<>();
        if (getPelisList().isEmpty()) {
            pelisDisponibles.add("No hi ha pel·lícules disponibles");
        } else {
            List<Pelicula> sortedList = getPelisList();
            sortedList.sort(new Comparator<Pelicula>() {
                public int compare(Pelicula a1, Pelicula a2) {
                    return (a1.getTitol().compareTo(a2.getTitol()));
                }
            });


            for (Pelicula p : sortedList) {
                pelisDisponibles.add(p.getTitol());
            }

        }
        return pelisDisponibles;
    }
    public Iterable<MultiValueResult> visualitzarPelisPerEstrena() {
        List<MultiValueResult> pelisDisponibles = new ArrayList<>();
        if (getPelisList().isEmpty()) {
            MultiValueResult m = new MultiValueResult();
            m.with("titol", "No hi ha pel·lícules disponibles");
            m.with("any", " ");

            pelisDisponibles.add(m);
        } else {
            List<Pelicula> sortedList = getPelisList();
            sortedList.sort(new Comparator<Pelicula>() {
                public int compare(Pelicula a1, Pelicula a2) {
                    return (Integer.compare(a2.getAnyEstrena(), a1.getAnyEstrena()));
                }
            });


            for (Pelicula p : sortedList) {
                MultiValueResult m = new MultiValueResult();
                m.with("titol", p.getTitol());
                m.with("any", p.getAnyEstrena());
                pelisDisponibles.add(m);
            }

        }
        return pelisDisponibles;
    }
    public Iterable<String> visualitzarPelisPerTematica(String nomTematica) {
        ArrayList<String> pelisDisponibles = new ArrayList<>();
        if (getPelisList().isEmpty()) {
            pelisDisponibles.add("No hi ha pel·lícules disponibles");
        } else {
            ArrayList<String> sortedList = new ArrayList<>();
            for (Pelicula p : getPelisList()) {
                ArrayList<Tematica> tematiques = p.getTematiques();

                for (Tematica t : tematiques) {
                    if (t.getNomTematica().equals(nomTematica)) {
                        sortedList.add(p.getTitol());
                    }
                }
            }
            sortedList.sort(new Comparator<String>() {
                public int compare(String a1, String a2) {
                    return (a1.compareTo(a2));
                }
            });
            for (String s : sortedList) {
                pelisDisponibles.add(s);
            }
        }

        return pelisDisponibles;
    }

    //Series
    public Iterable<String> visualitzarSeriesPerNom() {
        SortedSet<String> seriesDisponibles = new TreeSet<>();
        if (getSeriesList().isEmpty()) {
            seriesDisponibles.add("No hi ha sèries disponibles");
        } else {
            for (Serie r : getSeriesList()) {
                seriesDisponibles.add(r.getTitol());
            }
        }
        return seriesDisponibles;
    }
    public Iterable<String> visualitzarTemporadesSerie(String nomSerie) {
        SortedSet<String> temporadesDisponibles = new TreeSet<>();
        Serie serie = llistaSeries.get(nomSerie);
        if (serie == null) {
            temporadesDisponibles.add("Aquesta sèrie no està disponible en el sistema");
        } else {
            List<Temporada> temporades = serie.getTemporades();
            if (temporades.size() == 0) {
                temporadesDisponibles.add("Aquesta sèrie encara no té temporades");
            } else {
                for (Temporada t : serie.getTemporades()) {
                    temporadesDisponibles.add(String.valueOf(t.getNumTemporada()));
                }
            }
        }
        return temporadesDisponibles;
    }
    public Iterable<String> visualitzaEpisodisTemporadaSerie(String nomSerie, int numTemporada) {
        List<String> episodisDisponibles = new ArrayList<>();
        Serie serie = llistaSeries.get(nomSerie);
        if (serie == null) {
            episodisDisponibles.add("Aquesta sèrie no està disponible en el sistema");
        } else {
            List<Temporada> temporades = serie.getTemporades();
            if (temporades == null) {
                episodisDisponibles.add("Aquesta sèrie no té encara temporades");
            } else {
                int i = 0;
                boolean trobat = false;
                while  (i<temporades.size() && !trobat) {
                    Temporada temporada = serie.getTemporades().get(i);
                    if (temporada.getNumTemporada() == numTemporada) {
                        trobat = true;
                    } else i++;
                }
                if (trobat) {
                    Temporada temporada = serie.getTemporades().get(i);

                    List<Episodi> sortedList = temporada.getEpisodis();
                    sortedList.sort(new Comparator<Episodi>() {
                        public int compare(Episodi a1, Episodi a2) {
                            return (Integer.compare(a1.getNumEpisodi(), a2.getNumEpisodi()));
                        }
                    });


                    for (Episodi e : sortedList) {
                        episodisDisponibles.add(e.getTitol());
                    }
                } else {
                    episodisDisponibles.add("Aquesta sèrie no té aquesta temporada");
                }
            }
        }
        return episodisDisponibles;
    }
    //Metodos de servicio
    private List<Pelicula> getPelisList() {
        return new ArrayList<>(llistaPelicules.values());
    }
    private List<Serie> getSeriesList() {
        return new ArrayList<>(llistaSeries.values());
    }

    /*-----------------------------*/
    /*  Afegir Contingut  */
    /*-----------------------------*/
    public void afegirPelicula(String nom, Pelicula p) {
        llistaPelicules.put(nom, p);
    }
    public void afegirSerie(String nomSerie, Serie s) {
        llistaSeries.put(nomSerie, s);
    }
    public void afegirTemporada(String nomSerie, int numTemporada) throws ImUBException {

        Serie serie = llistaSeries.get(nomSerie);
        if (serie == null) {
            throw new ImUBException("Serie no disponible en el sistema");
        } else {
            List<Temporada> temporades = serie.getTemporades();
            if (temporades == null) {
                throw new ImUBException("Aquesta sèrie encara no té temporades disponibles");
            } else {
                int i = 0;
                boolean trobat = false;
                while  (i<temporades.size() && !trobat) {
                    Temporada temporada = serie.getTemporades().get(i);
                    if (temporada.getNumTemporada() == numTemporada) {
                        trobat = true;
                    } else i++;
                }
                if (trobat) {
                    throw new ImUBException("Aquesta temporada ja existeix");
                } else {
                    Temporada temporada = new Temporada(nomSerie, numTemporada);
                    serie.addTemporada(temporada);
                }
            }
        }
    }
    public void afegirEpisodi(String nomSerie, int numTemporada, int numEpisodi, String títolEpisodi, int durada) throws ImUBException {
        Serie serie = llistaSeries.get(nomSerie);
        if (serie == null) {
            throw new ImUBException("Serie no disponible en el sistema");
        } else {
            List<Temporada> temporades = serie.getTemporades();
            if (temporades == null) {
                throw new ImUBException("Aquesta sèrie encara no té temporades disponibles");
            } else {
                int i = 0;
                boolean trobat = false;
                while  (i<temporades.size() && !trobat) {
                    Temporada temporada = serie.getTemporades().get(i);
                    if (temporada.getNumTemporada() == numTemporada) {
                        trobat = true;
                    } else i++;
                }
                if (trobat) {
                    Temporada temporada = serie.getTemporades().get(i);
                    if (temporada.containsEpisodi(numEpisodi)) {
                        throw new ImUBException("Aquest episodi ja existeix");
                    } else {
                        Episodi episodi = new Episodi(nomSerie, numTemporada, numEpisodi, títolEpisodi, durada);
                        temporada.addEpisodi(episodi);
                    }
                } else {
                    throw new ImUBException("No existeix la temporada dins d'aquesta sèrie");
                }
            }
        }
    }

    /*-----------------------------*/
    /*  Valorar contingut          */
    /*-----------------------------*/
    public String valorarPelicula(String nomPeli, String user, int puntuacio, String tipusValoracio) {
        Client client = carteraClients.find(user);
        Pelicula pelicula = llistaPelicules.get(nomPeli);

        ValoracioClient valoracio = FactoryValoracio.createValoracio(tipusValoracio, puntuacio, client);
        return ValorarPelicula.execute(pelicula, valoracio);
    }
    public String valorarEpisodi(String nomSerie, int numTemp, int numEpisodi, String user, int puntuacio, String tipusValoracio){
        Client client = carteraClients.find(user);
        Episodi episodi = llistaSeries.get(nomSerie).getTemporades().get(numTemp-1).getEpisodis().get(numEpisodi-1); //intentar quitar los -1 y ponerlos en un nivel inferior

        ValoracioClient valoracio = FactoryValoracio.createValoracio(tipusValoracio, puntuacio, client);
        return ValorarEpisodi.execute(episodi, valoracio);
    }


    public String visualitzarValoracioPelicula(String nomPeli, String tipusValoracio, String tipusNumerica) {
        Pelicula peli = llistaPelicules.get(nomPeli);
        return VisualitzarValoracioPelicula.execute(peli, tipusValoracio, tipusNumerica);
    }
    public String visualitzarValoracioEpisodi(String nomSerie, int numTemp, int numEpisodi, String tipusValoracio, String tipusNumerica) {
        Serie serie = llistaSeries.get(nomSerie);
        if (serie == null) {return "Aquest contingut no està disponible en el sistema";}

        List<Temporada> temporades = serie.getTemporades();
        for(Temporada t: temporades){}
        if (numTemp <= 0 || numTemp > temporades.size()) {return "Aquest contingut no està disponible en el sistema";}

        Temporada temporada = temporades.get(numTemp - 1);
        ArrayList<Episodi> episodis = temporada.getEpisodis();

        if (numEpisodi <= 0 || numEpisodi > episodis.size()) {return "Aquest contingut no està disponible en el sistema";}
        Episodi episodi = episodis.get(numEpisodi - 1);
        return VisualitzarValoracioEpisodi.execute(episodi, tipusValoracio, tipusNumerica);
    }
    public String visualitzarValoracioTemporada(String nomSerie, int numTemp, String tipusValoracio, String tipusNumerica) {
        Serie serieObj = llistaSeries.get(nomSerie);
        if (serieObj == null) {return "Aquest contingut no està disponible en el sistema";}
        List<Temporada> temporades = serieObj.getTemporades();
        if (numTemp <= 0 || numTemp > temporades.size()) {return "Aquest contingut no està disponible en el sistema";}
        Temporada temporada = temporades.get(numTemp - 1);
        return VisualitzarValoracioTemporada.execute(temporada, tipusValoracio, tipusNumerica);
    }
    public String visualitzarValoracioSerie(String nomSerie, String tipusValoracio, String tipusNumerica) {
        Serie serie = llistaSeries.get(nomSerie);
        if (serie == null) {
            return "Aquest contingut no està disponible en el sistema";
        }
        return VisualitzarValoracioSerie.execute(serie, tipusValoracio,  tipusNumerica);
    }
    public String visualitzarTop5Pelicules(String tipusValoracio, String tipusNumerica) {
        return VisualitzarTop5Pelicules.execute(llistaPelicules, tipusValoracio, tipusNumerica);
    }
    public String visualitzarTop5Series(String tipusValoracio, String tipusNumerica) {
        return VisualitzarTop5Series.execute(llistaSeries, tipusValoracio, tipusNumerica);
    }

    /*-----------------------------*/
    /*  Comunitats  */
    /*-----------------------------*/
    public void afegirComunitat(String nom, Comunitat comunitat) {
        llistaComunitats.put(nom, comunitat);
    }
    public String afegirseComunitat(String user, String nomComunitat) throws ImUBException {
        Client client = carteraClients.find(user);
        Comunitat comunitat = llistaComunitats.get(nomComunitat);
        if (comunitat == null){
            throw new ImUBException("Aquesta comunitat no existeix");
        }
        client.addComunitat(comunitat);
        return "S'ha apuntat correctament a la comunitat";
    }

    /*-----------------------------*/
    /*  Metodos Generales  */
    /*-----------------------------*/
    public ContingutDigital trobatContingut(String nomContingut){
        ContingutDigital contingut = null;
        if (llistaPelicules.containsKey(nomContingut)){
            contingut = llistaPelicules.get(nomContingut);
        } else if (llistaSeries.containsKey(nomContingut)){
            contingut = llistaSeries.get(nomContingut);
        }
        return contingut;
    }
}
