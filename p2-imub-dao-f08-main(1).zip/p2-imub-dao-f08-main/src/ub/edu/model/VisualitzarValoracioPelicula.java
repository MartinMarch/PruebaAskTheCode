package ub.edu.model;

public class VisualitzarValoracioPelicula {
    public static String execute(Pelicula peli, String tipusValoracio, String tipusNumerica){
        if (peli == null) return "Aquest contingut no està disponible en el sistema";
        else return "La valoració mitja és de: " + peli.calcularValoracio(tipusValoracio, tipusNumerica);
    }
}
