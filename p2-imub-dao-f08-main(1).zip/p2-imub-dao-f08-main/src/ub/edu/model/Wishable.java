package ub.edu.model;

public interface Wishable {
    public String getTitol();
}
