package ub.edu.model;

import ub.edu.resources.service.DataService;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Validacions {
    public static boolean validarNumerica(int puntuacio) {
        return puntuacio >= 1 && puntuacio <= 10;
    }

    private static boolean isPasswordSegur(String password) {
        Pattern pattern = Pattern.compile("^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9]).{8,}$");
        Matcher matcher = pattern.matcher(password);
        return matcher.find();
    }
    private static boolean isMail(String correu) {
        Pattern pattern = Pattern.compile("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
                + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");
        Matcher matcher = pattern.matcher(correu);
        return matcher.find();
    }

    public static String validatePassword(String b) {
        if (!isPasswordSegur(b)) {
            return "Contrassenya no prou segura";
        } else
            return "Contrassenya segura";
    }


    public static String validateUsername(String b) {
        if (!isMail(b))
            return "Correu en format incorrecte";
        else
            return "Correu en format correcte";
    }

    // Validem la Client a la capa de persistencia i no a memoria, per seguretat en les possibles sincronitzacions
    public static String validateRegistreClient(DataService dataService, String username, String password) {
        if  (dataService.getClientByUsername(username).isPresent() )
            return "Client duplicat";
        else if (isMail(username) && isPasswordSegur(password))
            return "Registre vàlid";
        else return "Format incorrecte";
    }
    public static boolean validarEstrelles(int puntuacio) {
        return puntuacio >= 1 && puntuacio <= 5;
    }
    public static boolean validarLike(int puntuacio) {
        return puntuacio == 1 || puntuacio == 0;
    }
}
