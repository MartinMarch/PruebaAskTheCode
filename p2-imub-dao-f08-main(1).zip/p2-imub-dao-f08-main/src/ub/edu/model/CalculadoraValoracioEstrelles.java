package ub.edu.model;

import java.util.ArrayList;
import java.util.Iterator;

public class CalculadoraValoracioEstrelles implements CalculadoraValoracioStrategy {
    @Override
    public double calcularValoracio(ArrayList<ValoracioClient> llistaValoracions) {
        double sumaValoracioUsuaris = 0;
        int numValoracions = 0;

        for (ValoracioClient valoracio : llistaValoracions) {
            if (valoracio instanceof ValoracioEstrelles) {
                sumaValoracioUsuaris += ((ValoracioEstrelles) valoracio).getEstrelles();
                numValoracions++;
            }
        }

        if (sumaValoracioUsuaris == 0) {
            return sumaValoracioUsuaris;
        }
        return sumaValoracioUsuaris / numValoracions;

    }
}
