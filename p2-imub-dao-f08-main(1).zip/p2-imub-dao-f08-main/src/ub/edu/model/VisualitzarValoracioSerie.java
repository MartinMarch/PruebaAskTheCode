package ub.edu.model;

public class VisualitzarValoracioSerie {
    public static String execute(Serie serie, String tipusValoracio, String tipusNumerica){
        return "La valoració mitja és de: " + serie.calcularValoracio(tipusValoracio, tipusNumerica);
    }
}
