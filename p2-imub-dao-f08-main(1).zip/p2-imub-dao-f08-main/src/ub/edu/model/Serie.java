package ub.edu.model;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class Serie extends ContingutDigital implements Wishable{
    private List<Temporada> temporades;



    public Serie(String nomSerie, int anyEstrena){
        super(nomSerie, anyEstrena);
        temporades = new ArrayList<>();
    }

    public Serie(String nomSerie, String descripcio, String url, int anyEstrena, String idioma) {
        super(nomSerie, descripcio, anyEstrena, url, idioma);
        temporades = new ArrayList<>();
    }

    public void addTemporada(Temporada temporada){
        temporades.add(temporada);
    }

    public List<Temporada> getTemporades() { return temporades;}

    //nuevo
    public double calcularValoracio(String tipus, String tipusNumerica) {
        Iterator<Temporada> it = temporades.iterator();
        double sumaValoracions = 0;
        while(it.hasNext()){
            sumaValoracions += it.next().calcularValoracio(tipus, tipusNumerica);
        }
        if(sumaValoracions==0){
            return 0;
        }else{
            return sumaValoracions / temporades.size();
        }
    }


}