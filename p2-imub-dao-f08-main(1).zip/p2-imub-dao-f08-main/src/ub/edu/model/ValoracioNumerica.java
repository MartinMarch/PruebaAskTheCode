package ub.edu.model;

public class ValoracioNumerica extends ValoracioClient{
    private int puntuacio;


    public ValoracioNumerica(int puntuacio, Client client){
        super(client);
        this.puntuacio = puntuacio;
    }

    public int getPuntuacio() {
        return puntuacio;
    }
    public String tipusValoracio(){return "Numerica";}

    @Override
    public boolean isValid() {
        return Validacions.validarNumerica(puntuacio);
    }

    @Override
    public String errorMessage() {
        return ("La valoració ha de ser un número entre 1 i 10");
    }

    @Override
    public String successMessage(String contingut) {
        return (contingut+" valorat/da correctament");
    }
    @Override
    public boolean corresponde(String tipus, Client cliente) {
        return (tipus.equals("Numerica") && cliente.equals(getClient()));
    }
}
