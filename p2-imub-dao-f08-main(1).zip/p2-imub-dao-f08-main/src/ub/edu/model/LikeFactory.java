package ub.edu.model;

public class LikeFactory extends FactoryValoracio{
    public static ValoracioClient createValoracio(int puntuacio, Client client){
        return new ValoracioLike(puntuacio, client);
    }
}
