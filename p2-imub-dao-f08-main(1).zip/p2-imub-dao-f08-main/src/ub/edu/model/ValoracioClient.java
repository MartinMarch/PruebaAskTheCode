package ub.edu.model;

public abstract class ValoracioClient {
    private Client client;

    public ValoracioClient(Client client) {
        this.client = client;
    }
    public Client getClient() {
        return client;
    }
    public abstract String tipusValoracio();
    public abstract boolean isValid();
    public abstract String errorMessage();
    public abstract String successMessage(String contingut);
    public abstract boolean corresponde(String tipus, Client cliente);

}
