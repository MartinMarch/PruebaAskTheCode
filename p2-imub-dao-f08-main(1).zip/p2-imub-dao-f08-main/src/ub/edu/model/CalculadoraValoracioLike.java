package ub.edu.model;

import java.util.ArrayList;
import java.util.Iterator;

public class CalculadoraValoracioLike implements CalculadoraValoracioStrategy {
    @Override
    public double calcularValoracio(ArrayList<ValoracioClient> llistaValoracions) {
        int sumaValoracio = 0;
        int contador = 0;
        for (ValoracioClient valoracio : llistaValoracions) {
            if (valoracio instanceof ValoracioLike) {
                sumaValoracio+= ((ValoracioLike) valoracio).getLikeUnlike();
                contador++;
            }
        }
        if(sumaValoracio == 0){
            return sumaValoracio;
        }
        return ((double) sumaValoracio /contador)*10;
    }
}
