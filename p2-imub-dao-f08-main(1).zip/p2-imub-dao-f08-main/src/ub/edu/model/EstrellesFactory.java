package ub.edu.model;

public class EstrellesFactory extends FactoryValoracio {
    public static ValoracioClient createValoracio(int puntuacio, Client client){
        return new ValoracioEstrelles(puntuacio, client);
    }
}
