package ub.edu.model;


import java.util.ArrayList;

public class Client {
    private String pwd;
    private String nom;
    private WishList wishlist;
    private ArrayList<Comunitat> comunitats;
    private WatchedList watchedList;

    public Client(String nom, String pwd) {
        this.pwd = pwd;
        this.nom = nom;
        wishlist = new WishList();
        comunitats = new ArrayList<Comunitat>();
        watchedList = new WatchedList();
    }

    public String getPwd() {
        return pwd;
    }

    public String getName() {
        return nom;
    }

    public void setName(String nom) {
        this.nom = nom;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public WishList getWishList() {
        return wishlist;
    }

    public Comunitat getComunitat(String nom) {
        for (Comunitat c : comunitats) {
            if (c.getNom().equals(nom)) return c;
        }
        return null;
    }

    public void addComunitat(Comunitat c) throws ImUBException {
        if (comunitats.size()==5){
            throw new ImUBException("No ha estat possible unir-se a la comunitat, ja està apuntat al nombre màxim de comunitats");
        }else {
            comunitats.add(c);
        }
    }

    public WatchedList getWatchedList() {
        return watchedList;
    }

    public void esborrarComunitat(Comunitat c) {
        comunitats.remove(c);
    }
}
