package ub.edu.model;

public abstract class FactoryValoracio {
    public static ValoracioClient createValoracio(String tipus, int puntuacio, Client client){
        if (tipus.equals("Numerica")) { return  NumericaFactory.createValoracio(puntuacio, client); }
        else if (tipus.equals("Estrelles")) { return EstrellesFactory.createValoracio(puntuacio, client);}
        else if (tipus.equals("Like")) { return LikeFactory.createValoracio(puntuacio, client);}
        return null;
    }
}

