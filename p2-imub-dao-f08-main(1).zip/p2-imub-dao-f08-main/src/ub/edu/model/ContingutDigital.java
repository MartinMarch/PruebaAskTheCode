package ub.edu.model;

import java.util.ArrayList;

public abstract class ContingutDigital {
    protected String titol;
    protected String descripcio;
    protected int anyPrimeraEmissio;
    protected String imatge;
    protected String idioma;
    protected ArrayList<Tematica> llistaTematiques;

    public ContingutDigital(String titol, String descripcio, int anyPrimeraEmissio, String imatge, String idioma) {
        this.titol = titol;
        this.descripcio = descripcio;
        this.anyPrimeraEmissio = anyPrimeraEmissio;
        this.imatge = imatge;
        this.idioma = idioma;
        llistaTematiques = new ArrayList<Tematica>();
    }

    public ContingutDigital(String titol, int anyPrimeraEmissio) {
        this.titol = titol;
        this.anyPrimeraEmissio = anyPrimeraEmissio;
        llistaTematiques = new ArrayList<Tematica>();
    }

    public String getTitol() {
        return titol;
    }
    public void setTitol(String titol) {
        this.titol = titol;
    }
    public void addTematica(Tematica t) {
        this.llistaTematiques.add(t);
    }
    public ArrayList<Tematica> getTematiques() {
        return llistaTematiques;
    }
    public int getAnyEstrena() {
        return anyPrimeraEmissio;
    }

}
