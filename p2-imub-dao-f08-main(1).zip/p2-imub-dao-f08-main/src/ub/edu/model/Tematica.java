package ub.edu.model;

public class Tematica {
    private String nomTematica;

    public Tematica(String nomTematica) {
        this.nomTematica = nomTematica;
    }

    public String getNomTematica() {
        return nomTematica;
    }

    public void setNomTematica(String nomTematica) {
        this.nomTematica = nomTematica;
    }
}
