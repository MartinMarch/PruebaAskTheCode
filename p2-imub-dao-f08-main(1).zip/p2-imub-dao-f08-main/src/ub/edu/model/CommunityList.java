package ub.edu.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CommunityList {
    private ArrayList<ContingutDigital> list;
    private ArrayList<Tematica> tematiques;

    public CommunityList(){
        list = new ArrayList<>();
    }

    public void addContingut(ContingutDigital contingut){
        list.add(contingut);
    }
    public void removeContingut(ContingutDigital contingut){
        list.remove(contingut);
    }

    public List<ContingutDigital> getContingut() {
        return Collections.unmodifiableList(list);
    }
    public boolean isEmpty(){
        return list.isEmpty();
    }
    public boolean contains(ContingutDigital contingut){
        return list.contains(contingut);
    }
    public ArrayList<Tematica> getTematiques() {
        return tematiques;
    }
    public void addTematica(Tematica t) {
        tematiques.add(t);
    }
}
