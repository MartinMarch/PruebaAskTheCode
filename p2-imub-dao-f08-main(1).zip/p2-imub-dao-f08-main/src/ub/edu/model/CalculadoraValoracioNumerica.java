package ub.edu.model;

import java.sql.SQLOutput;
import java.util.ArrayList;
import java.util.Iterator;

public class CalculadoraValoracioNumerica implements CalculadoraValoracioStrategy {
    @Override
    public double calcularValoracio(ArrayList<ValoracioClient> llistaValoracions) {
        double sumaValoracioUsuaris = 0;
        int numValoracions = 0;

        for (ValoracioClient valoracio : llistaValoracions) {
            if (valoracio instanceof ValoracioNumerica) {
                sumaValoracioUsuaris += ((ValoracioNumerica) valoracio).getPuntuacio();
                numValoracions++;
            }
        }
        if (sumaValoracioUsuaris == 0) {
            return sumaValoracioUsuaris;
        }
        return sumaValoracioUsuaris / numValoracions;


    }
    @Override
    public double calcularValoracio(ArrayList<ValoracioClient> llistaValoracions, float valoracioInicial) {
        double sumaValoracioUsuaris = 0;
        int numValoracions = 0;

        for (ValoracioClient valoracio : llistaValoracions) {
            if (valoracio instanceof ValoracioNumerica) {
                sumaValoracioUsuaris += ((ValoracioNumerica) valoracio).getPuntuacio();
                numValoracions++;
            }
        }

        if (sumaValoracioUsuaris == 0) {
            return valoracioInicial*0.5;
        }


        double mediaValoracionsUsuaris = sumaValoracioUsuaris / numValoracions;
        double valoracioFinal = (mediaValoracionsUsuaris * 0.5) + (valoracioInicial * 0.5);

        return valoracioFinal;
    }
}
