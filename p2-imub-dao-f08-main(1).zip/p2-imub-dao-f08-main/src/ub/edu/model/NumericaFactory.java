package ub.edu.model;

public class NumericaFactory extends FactoryValoracio{
    public static ValoracioClient createValoracio(int puntuacio, Client client){
        return new ValoracioNumerica(puntuacio, client);
    }
}
