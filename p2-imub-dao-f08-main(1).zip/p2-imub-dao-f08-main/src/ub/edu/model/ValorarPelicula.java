package ub.edu.model;

public class ValorarPelicula {
    public static String execute(Pelicula peli, ValoracioClient valoracio) {
        Client client = valoracio.getClient();
        String tipusValoracio = valoracio.tipusValoracio();

        if (peli.isValorado(tipusValoracio, client)) {
            return ("Aquesta pel·lícula ja ha estat valorada");
        }
        if(!valoracio.isValid()) {
            return valoracio.errorMessage();
        }
        else{
            peli.afegirValoracio(valoracio);
            client.getWatchedList().agregarPelicula(peli); //TO DO revisar si queremos sacarlo
            return valoracio.successMessage("Pel·lícula");
        }
    }


}
