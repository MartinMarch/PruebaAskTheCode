package ub.edu.model;

import java.util.ArrayList;
import java.util.Iterator;

public class Episodi implements GestorContingut, Comparable<Episodi>{
    // Episodi: nomSerie, numTemporada, numEpisodi, títolEpisodi, durada, descripció, data d’estrena
    private String nomSerie;
    private int numTemporada;
    private int numEpisodi;
    private String titolEpisodi;
    private int durada;
    private float valoracioInicial;
    private ArrayList<ValoracioClient> llistaValoraciones= new ArrayList<ValoracioClient>();

    public Episodi(String nomSerie, int numTemporada, int numEpisodi, String títolEpisodi, int durada){
        this.nomSerie = nomSerie;
        this.numTemporada = numTemporada;
        this.numEpisodi = numEpisodi;
        this.titolEpisodi = títolEpisodi;
        this.durada = durada;
        this.valoracioInicial = 0;
        this.llistaValoraciones = new ArrayList<ValoracioClient>();
    }

    public Episodi(String nomSerie, int numTemporada, int numEpisodi, String titolEpisodi, int durada, float valoracioInicial) {
        this.nomSerie = nomSerie;
        this.numTemporada = numTemporada;
        this.numEpisodi = numEpisodi;
        this.titolEpisodi = titolEpisodi;
        this.durada = durada;
        this.valoracioInicial = valoracioInicial;
        this.llistaValoraciones = new ArrayList<ValoracioClient>();
    }


    public int getNumEpisodi() {
        return numEpisodi;
    }

    public String getTitol() {
        return titolEpisodi;
    }

    public String getNomSerie() {
        return nomSerie;
    }

    public String getTitolEpisodi() {
        return titolEpisodi;
    }

    public int getNumTemporada() {
        return numTemporada;
    }

    public void setTitolEpisodi(String nom) {
        this.titolEpisodi = nom;
    }

    //Nuevo
    public int getDurada() {
        return durada;
    }
    public ArrayList<ValoracioClient> getLlistaValoracions() {
        return llistaValoraciones;
    }

    //me puedes hacer un metodo toString con la informacion entera de un episodio?
    @Override
    public String toString() {
        return "Episodi{" + "nomSerie='" + nomSerie + '\'' + ", numTemporada=" + numTemporada + ", numEpisodi=" + numEpisodi + ", titolEpisodi='" + titolEpisodi;
    }

    @Override
    public boolean isValorado(String tipus, Client cliente) {
        for (ValoracioClient v : llistaValoraciones) {
            if (v.corresponde(tipus, cliente)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public void afegirValoracio(ValoracioClient valoracio) {
        llistaValoraciones.add(valoracio);
    }
    public double calcularValoracio(String tipus, String tipusNumerica) {
        CalculadoraValoracioStrategy c = FactoryCalculadora.createCalculadora(tipus);
        if (c == null) {
            return 0;
        }
        if (tipus.equals("Numerica")) {
            if(tipusNumerica.equals("Inicial")){
                return c.calcularValoracio(llistaValoraciones, valoracioInicial);
            }
        }
        return c.calcularValoracio(llistaValoraciones);
    }
    @Override
    public int compareTo(Episodi otro) {
        // Esto ordenará los episodios por su número de forma ascendente
        return Integer.compare(this.numEpisodi, otro.numEpisodi);
    }

}
