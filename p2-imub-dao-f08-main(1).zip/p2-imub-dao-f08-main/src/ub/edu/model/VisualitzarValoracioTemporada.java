package ub.edu.model;

public class VisualitzarValoracioTemporada {

    public static String execute(Temporada temporada, String tipusValoracio, String tipusNumerica){
        return "La valoració mitja és de: " + temporada.calcularValoracio(tipusValoracio, tipusNumerica);
    }
}
