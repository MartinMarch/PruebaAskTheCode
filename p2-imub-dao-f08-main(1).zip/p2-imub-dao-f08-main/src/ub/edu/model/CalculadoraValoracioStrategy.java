package ub.edu.model;

import java.util.ArrayList;

public interface CalculadoraValoracioStrategy {
    double calcularValoracio(ArrayList<ValoracioClient> llistaValoracions);
    default double calcularValoracio(ArrayList<ValoracioClient> llistaValoracions, float valoracioInicial){
        return calcularValoracio(llistaValoracions);
    }
}
