package ub.edu.model;

public class FactoryCalculadora {
    public static CalculadoraValoracioStrategy createCalculadora(String tipus){
        switch (tipus) {
            case "Numerica":
                return new CalculadoraValoracioNumerica();
            case "Estrelles":
                return new CalculadoraValoracioEstrelles();
            case "Like":
                return new CalculadoraValoracioLike();
            default:
                return null;
        }
    }
}
