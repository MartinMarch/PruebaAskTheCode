package ub.edu.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class VisualitzarTop5Series {
    public static String execute(Map<String, Serie> llistaSeries, String tipusValoracio, String tipusNumerica) {
        Map<Double, Serie> seriesOrdenades = new HashMap<>();
        String top5="";
        for (Map.Entry<String, Serie> entry : llistaSeries.entrySet()) {
            Serie serie = entry.getValue();
            double valoracio = serie.calcularValoracio(tipusValoracio, tipusNumerica);
            seriesOrdenades.put(valoracio, serie);
        }


        // Ordenar y obtener las top 5 películas
        List<Map.Entry<Double, Serie>> top5Pelicules = seriesOrdenades.entrySet().stream()
                .sorted(Map.Entry.<Double, Serie>comparingByKey().reversed()) // Ordena por la llave (valoración) en orden descendente
                .limit(5) // Limita a las 5 primeras entradas
                .collect(Collectors.toList());

        // Mostrar las películas
        for (Map.Entry<Double, Serie> entry : top5Pelicules) {
            Serie serie = entry.getValue();
            double valoracio = entry.getKey();
            top5 += serie.getTitol()+" - Valoración: " + valoracio+"\n";
        }
        return top5;
    }
}
