package ub.edu.model;

public class ImUBException extends Exception{
    public ImUBException(String message) {
        super(message);
    }
}
