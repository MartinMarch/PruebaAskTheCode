package ub.edu.model;

public class ValorarEpisodi {
    public static String execute(Episodi episodi, ValoracioClient valoracio) {
        Client client = valoracio.getClient();
        String tipusValoracio = valoracio.tipusValoracio();

        if (episodi.isValorado(tipusValoracio, client)) {
            return ("Aquest episodi ja ha estat valorat");
        }
        if(!valoracio.isValid()) {
            return valoracio.errorMessage();
        }
        else{
            episodi.afegirValoracio(valoracio);
            client.getWatchedList().agregarEpisodio(episodi); //TO DO revisar si queremos sacarlo
            return valoracio.successMessage("Episodi");
        }
    }


}
