package ub.edu.model;

import java.util.*;

import static java.util.Collections.*;

public class Temporada {
    private int numTemporada;
    private String nomSerie;

    private ArrayList<Episodi> episodis;

    public Temporada(String nomSerie, int i) {
        this.nomSerie = nomSerie;
        this.numTemporada = i;
        episodis = new ArrayList<Episodi>();
    }

    public String getNomSerie() {
        return nomSerie;
    }

    public void setNomSerie(String nomSerie) {
        this.nomSerie = nomSerie;
    }
    
    public void addEpisodi(Episodi episodi){
        episodis.add(episodi);
    }

    public int getNumTemporada() {
        return numTemporada;
    }

    public ArrayList<Episodi> getEpisodis() {
        ArrayList<Episodi> sortedEpisodis = new ArrayList<>(episodis);
        Collections.sort(sortedEpisodis); // Ahora funcionará porque Episodi es Comparable
        return sortedEpisodis;
    }

    //nuevo
    public boolean containsEpisodi(int numEpisodi){
        for (Episodi e: episodis) {
            if (e.getNumEpisodi() == numEpisodi) return true;
        }
        return false;
    }

    public double calcularValoracio(String tipus, String tipusNumerica) {
        Iterator<Episodi> it = episodis.iterator();
        double sumaValoracions = 0;
        while(it.hasNext()){
            sumaValoracions += it.next().calcularValoracio(tipus, tipusNumerica);
        }
        if(sumaValoracions==0){
            return 0;
        }else{
            return sumaValoracions / episodis.size();
        }
    }

    @Override
    public String toString() {
        return "Temporada{" + "nomSerie='" + nomSerie + '\'' + ", numTemporada=" + numTemporada;
    }


}
