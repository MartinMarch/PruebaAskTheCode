package ub.edu.model;

import java.util.ArrayList;

public class Comunitat {
    private String nom;
    private String descripcio;
    private CommunityList list;
    private ArrayList<Tematica> tematiques;

    public Comunitat(String nom, String descripcio) {
        this.nom = nom;
        this.descripcio = descripcio;
        list = new CommunityList();
        tematiques = new ArrayList<Tematica>();
    }

    public String getNom() {
        return nom;
    }
    public String setNom(String nom) {
        return this.nom = nom;
    }

    public void addTematica(Tematica t) throws ImUBException {
        if (tematiques.size() < 3) {
            this.tematiques.add(t);
        }else{
            throw new ImUBException("No es pot afegir més temàtiques a la comunitat");
        }
    }

    public CommunityList getCommunityList() {
        return list;
    }
    public ArrayList<Tematica> getTematiques() {
        return tematiques;
    }
}
