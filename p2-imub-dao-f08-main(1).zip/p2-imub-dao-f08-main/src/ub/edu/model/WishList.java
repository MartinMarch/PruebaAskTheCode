package ub.edu.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class WishList {
    private ArrayList<Wishable> wished;

    public WishList(){
        wished = new ArrayList<>();
    }

    public void afegirContingut(Wishable wishable){
        wished.add(wishable);
    }

    public void esborrarContingut(Wishable wishable){
        wished.remove(wishable);
    }

    public List<Wishable> getContingut() {
        return Collections.unmodifiableList(wished);
    }
    public boolean isEmpty(){
        return wished.isEmpty();
    }
    public boolean contains(Wishable wishable){
        return wished.contains(wishable);
    }


}
