package ub.edu.model;

import java.util.ArrayList;

public class WatchedList {
    private ArrayList<Object> vistos;

    public WatchedList(){
        vistos = new ArrayList<>();
    }

    public void agregarEpisodio(Episodi episodio){
        vistos.add(episodio);
    }
    public void agregarPelicula(Pelicula pelicula){
        vistos.add(pelicula);
    }
}
