package ub.edu.model;

public class ValoracioEstrelles extends ValoracioClient{
    private int estrelles;

    public ValoracioEstrelles(int estrelles, Client client){
        super(client);
        this.estrelles = estrelles;
    }

    public int getEstrelles() {
        return estrelles;
    }
    public String tipusValoracio() { return "Estrelles"; }

    @Override
    public boolean isValid() {
        return Validacions.validarEstrelles(estrelles);
    }
    @Override
    public String errorMessage() {
        return ("La valoració ha de ser un número entre 1 i 5");
    }
    @Override
    public String successMessage(String contingut) {
        return (contingut+ " valorat/da correctament");
    }
    @Override
    public boolean corresponde(String tipus, Client cliente) {
        return (tipus.equals("Estrelles") && cliente.equals(getClient()));
    }
}
