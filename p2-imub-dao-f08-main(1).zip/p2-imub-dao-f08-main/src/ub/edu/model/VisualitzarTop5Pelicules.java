package ub.edu.model;

import java.util.*;
import java.util.stream.Collectors;

public class VisualitzarTop5Pelicules {
    public static String execute(Map<String, Pelicula> llistaPelicules, String tipusValoracio, String tipusNumerica) {
        Map<Double, Pelicula> peliculesOrdenades = new HashMap<>();
        String top5 = "";
        for (Map.Entry<String, Pelicula> entry : llistaPelicules.entrySet()) {
            Pelicula pelicula = entry.getValue();
            double valoracio = pelicula.calcularValoracio(tipusValoracio, tipusNumerica);
            peliculesOrdenades.put(valoracio, pelicula);
        }

        // Ordenar y obtener las top 5 películas
        List<Map.Entry<Double, Pelicula>> top5Pelicules = peliculesOrdenades.entrySet().stream()
                .sorted(Map.Entry.<Double, Pelicula>comparingByKey().reversed()) // Ordena por la llave (valoración) en orden descendente
                .limit(5) // Limita a las 5 primeras entradas
                .collect(Collectors.toList());

        // Mostrar las películas
        for (Map.Entry<Double, Pelicula> entry : top5Pelicules) {
            Pelicula pelicula = entry.getValue();
            double valoracio = entry.getKey();
            top5+= pelicula.getTitol() + " - Valoración: " + valoracio+"\n";
        }
        return top5;
    }
}
