package ub.edu.model;

import java.util.ArrayList;
import java.util.List;

public class GestorCommunityList {
    private Comunitat comunitat;
    private CommunityList communityList;

    public GestorCommunityList(Comunitat comunitat) {
        this.comunitat = comunitat;
        communityList = comunitat.getCommunityList();
    }

    public Iterable<String> visualitzarCommunityList() {
        List<String> contingut = new ArrayList<>();
        if (communityList.isEmpty()) {
            contingut.add("No hi ha contingut per mostrar");
        } else {
            for (ContingutDigital c : communityList.getContingut()) {
                contingut.add(c.getTitol());
            }
        }
        return contingut;
    }

    public void afegirContingut(ContingutDigital contingut) throws ImUBException {
        for (Tematica t : contingut.getTematiques()) {
            for (Tematica t2 : communityList.getTematiques()) {
                if (t.getNomTematica().equals(t2.getNomTematica())) {
                    communityList.addContingut(contingut);
                    return;
                }
            }
        }
        throw new ImUBException("La temàtica del contingut no coincideix amb la temàtica de la comunitat");
    }

    public void esborrarContingut(ContingutDigital contingut) {
        communityList.removeContingut(contingut);
    }
}
