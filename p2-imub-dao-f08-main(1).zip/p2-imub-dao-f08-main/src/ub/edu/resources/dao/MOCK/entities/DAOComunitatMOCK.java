package ub.edu.resources.dao.MOCK.entities;

import ub.edu.model.Comunitat;
import ub.edu.model.ContingutDigital;
import ub.edu.model.Pelicula;
import ub.edu.model.Serie;
import ub.edu.resources.dao.entities.DAOComunitat;

import java.util.*;

public class DAOComunitatMOCK implements DAOComunitat {
    private final Map<String, Comunitat> comunitats = new HashMap<>();

    public DAOComunitatMOCK() {
        addComunitat("Tacos de sal", "Contenido principalmente de accion");
        addComunitat("Equipo Alfa Buena Dinamita Onda Escuadron Lobo", "Puro contenido del bueno");
        addComunitat("Los 4 fantásticos", "Contenido de superhéroes");
        addComunitat("Detectives de bajo presupuesto", "Contenido tipo policíaco y de crimenes para todas las edades");
        addComunitat("Wannabes prota de comedias romanticas", "Todo el contenido romantico que puedas digerir");
        addComunitat("Aqui no apoyamos al pintor austriaco de bigote chistoso", "Contenido de guerra y de historia");

        // Tacos de sal: Contenido principalmente de acción
        addContingutToCommunityList("Tacos de sal", new Pelicula("Inception", "A thief who enters the subconscious of his targets", "URL-inception", 2010, "English", 148, 10));
        addContingutToCommunityList("Tacos de sal", new Pelicula("The Dark Knight", "Batman faces a new adversary, the Joker", "URL_darkknight", 2008, "English", 126, 10));
        addContingutToCommunityList("Tacos de sal", new Pelicula("Avengers: Endgame", "The Avengers take a final stand against Thanos", "URL_endgame", 2019, "English", 181, 9));
        addContingutToCommunityList("Tacos de sal", new Serie("Breaking Bad", "A high school teacher turned methamphetamine manufacturer", "URL_breakingbad", 2008, "English"));

        // Equipo Alfa Buena Dinamita Onda Escuadron Lobo: Puro contenido del bueno
        addContingutToCommunityList("Equipo Alfa Buena Dinamita Onda Escuadron Lobo", new Pelicula("The Matrix", "A computer hacker learns about the nature of reality", "URL-matrix", 1999, "English", 136, 9));
        addContingutToCommunityList("Equipo Alfa Buena Dinamita Onda Escuadron Lobo", new Pelicula("Shawshank Redemption", "A man is sentenced to life in Shawshank State Penitentiary", "URL-shawshank", 1994, "English", 144, 7.5f));
        addContingutToCommunityList("Equipo Alfa Buena Dinamita Onda Escuadron Lobo", new Pelicula("The Godfather", "The story of a mafia family", "URL_godfather", 1972, "English", 215, 10));
        addContingutToCommunityList("Equipo Alfa Buena Dinamita Onda Escuadron Lobo", new Serie("Game of Thrones", "A series about the fight for the Iron Throne", "URL_got", 2011, "English"));

        // Los 4 fantásticos: Contenido de superhéroes
        addContingutToCommunityList("Los 4 fantásticos", new Pelicula("Interstellar", "A team of explorers travel through a wormhole in space", "URL-interstellar", 2014, "English", 169, 9.5f));
        addContingutToCommunityList("Los 4 fantásticos", new Serie("Stranger Things", "When a young boy vanishes, a small town uncovers a mystery involving secret experiments, terrifying supernatural forces and one strange little girl.", "URL_strangerthings", 2016, "English"));
        addContingutToCommunityList("Los 4 fantásticos", new Serie("The Mandalorian", "A lone gunfighter makes his way through the galaxy", "URL_mandalorian", 2019, "English"));
        addContingutToCommunityList("Los 4 fantásticos", new Serie("The Witcher", "The tale of Geralt of Rivia, a solitary monster hunter", "URL_witcher", 2019, "English"));

        // Detectives de bajo presupuesto: Contenido tipo policíaco y de crímenes para todas las edades
        addContingutToCommunityList("Detectives de bajo presupuesto", new Serie("Chernobyl", "A series about the Chernobyl nuclear disaster", "URL_chernobyl", 2019, "English"));
        addContingutToCommunityList("Detectives de bajo presupuesto", new Serie("Peaky Blinders", "A gangster family in Birmingham, England, in 1919", "URL_peaky", 2013, "English"));
        // Aquí puedes añadir más contenido relacionado con crímenes o investigaciones

        // Wannabes prota de comedias romanticas: Todo el contenido romántico que puedas digerir
        // Aquí puedes añadir películas o series con temática romántica

        // Aqui no apoyamos al pintor austriaco de bigote chistoso: Contenido de guerra y de historia
        // Aquí puedes añadir más contenido relacionado con guerra e historia
    }
    private void addComunitat(String nom, String descripcio) {
        Comunitat comunitat = new Comunitat(nom, descripcio);
        comunitats.put(nom, comunitat);
    }
    private void addContingutToCommunityList(String nomComunitat, ContingutDigital contingut) {
        Comunitat comunitat = comunitats.get(nomComunitat);
        if (comunitat != null) {
            comunitat.getCommunityList().addContingut(contingut);
        }
    }

    @Override
    public List<Comunitat> getAll() throws Exception {
        return new ArrayList<>(comunitats.values()); // Devuelve una copia de la lista para evitar modificaciones externas.
    }

    @Override
    public boolean add(Comunitat comunitat) throws Exception {
        if (getById(new String[]{comunitat.getNom()}).isPresent()) {
            return false;
        }
        comunitats.put(comunitat.getNom(), comunitat);
        return true;
    }

    @Override
    public boolean delete(Comunitat comunitat) throws Exception {
        return comunitats.remove(comunitat.getNom()) != null;
    }

    @Override
    public Optional<Comunitat> getById(String[] id) throws Exception {
        return Optional.ofNullable(comunitats.get(Objects.requireNonNull(Integer.parseInt(id[0]), "Comunitat nom cannot be null")));
    }

    @Override
    public boolean update(Comunitat comunitat, String[] params) throws Exception {
        comunitat.setNom(Objects.requireNonNull(
                params[0], "Comunitat nom cannot be null"));
        return comunitats.replace(comunitat.getNom(), comunitat) != null;
    }

}
