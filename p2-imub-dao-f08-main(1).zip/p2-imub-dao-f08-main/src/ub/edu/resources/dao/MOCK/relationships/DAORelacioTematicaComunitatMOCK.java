package ub.edu.resources.dao.MOCK.relationships;

import ub.edu.resources.dao.Parell;
import ub.edu.resources.dao.relationships.DAORelacioTematicaComunitat;

public class DAORelacioTematicaComunitatMOCK extends DAORelacioMOCK<Parell<String, String>> implements DAORelacioTematicaComunitat {
    public DAORelacioTematicaComunitatMOCK() {
        addTematicaComunitat("Action", "Tacos de sal");
        addTematicaComunitat("Sci-Fi", "Equipo Alfa Buena Dinamita Onda Escuadron Lobo");
        addTematicaComunitat("Adventure", "Equipo Alfa Buena Dinamita Onda Escuadron Lobo");
        addTematicaComunitat("Superhero", "Los 4 fantásticos");
        addTematicaComunitat("Sci-Fi", "Los 4 fantásticos");
        addTematicaComunitat("Crime", "Detectives de bajo presupuesto");
        addTematicaComunitat("Mystery", "Detectives de bajo presupuesto");
        addTematicaComunitat("Documentary", "Detectives de bajo presupuesto");
        addTematicaComunitat("Comedy", "Wannabes prota de comedias romanticas");
        addTematicaComunitat("Romance", "Wannabes prota de comedias romanticas");
        addTematicaComunitat("War", "Aqui no apoyamos al pintor austriaco de bigote chistoso");
        addTematicaComunitat("History", "Aqui no apoyamos al pintor austriaco de bigote chistoso");
    }

    private boolean addTematicaComunitat(String nomTematica, String nomComunitat) {
        return relacions.add(new Parell<>(nomTematica, nomComunitat));
    }
}
