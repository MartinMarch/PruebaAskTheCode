package ub.edu.resources.dao.MOCK.relationships;

import ub.edu.resources.dao.Parell;
import ub.edu.resources.dao.relationships.DAORelacioTematicaSeries;

public class DAORelacioTematicaSeriesMOCK extends DAORelacioMOCK<Parell<String, String>> implements DAORelacioTematicaSeries {
    public DAORelacioTematicaSeriesMOCK() {
        addTematicaSerie("Sci-Fi","Stranger Things");
        addTematicaSerie("Action", "Game of Thrones");
        addTematicaSerie("Sci-Fi", "The Mandalorian");
        addTematicaSerie("Adventure", "Chernobyl");
        addTematicaSerie("Adventure", "Peaky Blinders");
        addTematicaSerie("Drama", "Friends");
        addTematicaSerie("Sci-Fi", "The Big Bang Theory");
        addTematicaSerie("Sci-Fi", "The Witcher");
        addTematicaSerie("Action", "Breaking Bad");
        addTematicaSerie("Drama", "The Office");
    }

    private boolean addTematicaSerie(String nomTematica, String nomSerie) {
        return relacions.add(new Parell<>(nomTematica, nomSerie));
    }
}
