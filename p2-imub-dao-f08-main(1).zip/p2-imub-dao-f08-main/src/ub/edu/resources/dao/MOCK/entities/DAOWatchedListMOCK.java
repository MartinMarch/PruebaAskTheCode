package ub.edu.resources.dao.MOCK.entities;

import ub.edu.model.Temporada;
import ub.edu.model.WatchedList;
import ub.edu.resources.dao.entities.DAOWatchedList;
import ub.edu.resources.dao.Parell;

import java.util.*;
public class DAOWatchedListMOCK implements DAOWatchedList{

    @Override
    public List<WatchedList> getAll() throws Exception {
        return null;
    }

    @Override
    public boolean add(WatchedList watchedList) throws Exception {
        return false;
    }

    @Override
    public boolean delete(WatchedList watchedList) throws Exception {
        return false;
    }

    @Override
    public Optional<WatchedList> getById(String[] id) throws Exception {
        return Optional.empty();
    }

    @Override
    public boolean update(WatchedList watchedList, String[] params) throws Exception {
        return false;
    }
}
