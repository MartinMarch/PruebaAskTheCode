package ub.edu.resources.dao.entities;

import ub.edu.model.Serie;
import ub.edu.resources.dao.DAOEntity;

public interface DAOSerie extends DAOEntity<Serie> {
}
