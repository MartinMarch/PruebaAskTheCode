package ub.edu.resources.dao.entities;

import ub.edu.model.Pelicula;
import ub.edu.resources.dao.DAOEntity;

public interface DAOPelicula extends DAOEntity<Pelicula> {
}
