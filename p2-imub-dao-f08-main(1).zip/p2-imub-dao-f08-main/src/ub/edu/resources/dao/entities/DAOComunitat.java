package ub.edu.resources.dao.entities;

import ub.edu.model.CommunityList;
import ub.edu.model.Comunitat;
import ub.edu.resources.dao.DAOEntity;

public interface DAOComunitat extends DAOEntity<Comunitat> {
}
