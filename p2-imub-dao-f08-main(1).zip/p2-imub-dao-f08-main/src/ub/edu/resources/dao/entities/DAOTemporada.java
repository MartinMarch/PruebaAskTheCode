package ub.edu.resources.dao.entities;

import ub.edu.model.Temporada;
import ub.edu.resources.dao.DAOEntity;

public interface DAOTemporada extends DAOEntity<Temporada> {

}
