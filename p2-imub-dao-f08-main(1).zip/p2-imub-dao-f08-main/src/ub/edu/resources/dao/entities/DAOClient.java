package ub.edu.resources.dao.entities;

import ub.edu.model.Client;
import ub.edu.resources.dao.DAOEntity;

public interface DAOClient extends DAOEntity<Client>
{

}
