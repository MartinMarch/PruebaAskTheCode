package ub.edu.resources.dao.entities;

import ub.edu.model.Tematica;
import ub.edu.resources.dao.DAOEntity;

public interface DAOTematica extends DAOEntity<Tematica> {
}
