package ub.edu.resources.dao.entities;

import ub.edu.model.Episodi;
import ub.edu.resources.dao.DAOEntity;

public interface DAOEpisodi extends DAOEntity<Episodi> {

}
