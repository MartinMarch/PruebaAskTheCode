package ub.edu.resources.dao.entities;

import ub.edu.model.WatchedList;
import ub.edu.resources.dao.DAOEntity;
public interface DAOWatchedList extends DAOEntity<WatchedList> {
}
