package ub.edu.resources.dao.relationships;

import ub.edu.resources.dao.DAO;
import ub.edu.resources.dao.Parell;

public interface DAORelacioTematicaComunitat extends DAO<Parell<String, String>> {
}
