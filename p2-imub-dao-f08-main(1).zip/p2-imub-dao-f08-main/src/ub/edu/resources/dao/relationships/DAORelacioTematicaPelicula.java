package ub.edu.resources.dao.relationships;

import ub.edu.resources.dao.DAO;
import ub.edu.resources.dao.Parell;

public interface DAORelacioTematicaPelicula extends DAO<Parell<String, String>>{
}
