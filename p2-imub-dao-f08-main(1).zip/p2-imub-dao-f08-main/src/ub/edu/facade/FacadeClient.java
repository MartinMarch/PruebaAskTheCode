package ub.edu.facade;

import ub.edu.model.*;

public class FacadeClient {
    private ImUB imub;

    public FacadeClient(ImUB imub) {
        this.imub = imub;
    }

    public String findClient(String username) {
        return imub.findClient(username);
    }

    public String loguejarClient(String username, String password) throws ImUBException {
        return imub.loguejarClient(username, password);
    }

    public String recuperarContrassenya(String username) throws ImUBException {
        return imub.recuperarContrassenya(username);
    }

    public Client getClient(String username) throws ImUBException {
        return imub.getClient(username);
    }

    /*-----------------------------*/
    /*  WishList  */
    /*-----------------------------*/
    public String afegirContingutWishList(String nomContingut, String user) throws ImUBException {
        Client client = imub.getClient(user);
        Wishable contingut = null;
        try {
            contingut = (Wishable) imub.trobatContingut(nomContingut);
        }catch (ClassCastException e){
            throw new ImUBException ("Aquest contingut no es pot afegir a la WishList");
        }

        if (client == null){
            throw new ImUBException ("Aquest client no existeix");
        } else{
            GestorWishlist gestorWishlist = new GestorWishlist(client.getWishList());
            return gestorWishlist.afegirContingut(contingut);
        }
    }
    public String esborrarContingutWishList(String nomContingut, String user) throws ImUBException {
        Client client = imub.getClient(user);
        Wishable contingut = null;
        try {
            contingut = (Wishable) imub.trobatContingut(nomContingut);
        }catch (ClassCastException e){
            throw new ImUBException ("Aquest contingut no es pot esborrar de la WishList");
        }

        if (client == null){
            throw new ImUBException ("Aquest client no existeix");
        } else{
            GestorWishlist gestorWishlist = new GestorWishlist(client.getWishList());
            return gestorWishlist.esborrarContingut(contingut);
        }
    }
    public Iterable<String> visualitzarWishList(String user) throws ImUBException {
        Client client = imub.getClient(user);
        GestorWishlist gestorWishlist = new GestorWishlist(client.getWishList());
        return gestorWishlist.visualitzarWishlist();
    }


}
