package ub.edu.facade;

import org.concordion.api.MultiValueResult;
import ub.edu.model.ImUB;
import ub.edu.model.ImUBException;
import ub.edu.model.Pelicula;
import ub.edu.model.Serie;

public class FacadeContingut {
    private ImUB imub;

    public FacadeContingut(ImUB imub) {
        this.imub = imub;
    }

    /*-----------------------------*/
    /*-- Afegir --*/
    /*-----------------------------*/
    public void afegirPelicula(String nom, int estrena, int durada) {
        Pelicula p = new Pelicula(nom, estrena, durada);
        imub.afegirPelicula(nom, p);
    }
    public void afegirSerie(String nomSerie, int anyEstrena) {
        Serie s = new Serie(nomSerie, anyEstrena);
        imub.afegirSerie(nomSerie, s);
    }
    public void afegirTemporada(String nomSerie, int numTemporada) throws ImUBException {
        imub.afegirTemporada(nomSerie, numTemporada);
    }
    public void afegirEpisodi(String nomSerie, int numTemporada, int numEpisodi, String nomEpisodi, int duracio) throws ImUBException {
        imub.afegirEpisodi(nomSerie, numTemporada, numEpisodi, nomEpisodi, duracio);
    }

    /*-----------------------------*/
    /*-- Visualitzar --*/
    /*-----------------------------*/
    public Iterable<String> visualitzarPelisPerNom() {
        return imub.visualitzarPelisPerNom();
    }
    public Iterable<MultiValueResult> visualitzarPelisPerEstrena() {
        return imub.visualitzarPelisPerEstrena();
    }
    public Iterable<String> visualitzarPelisPerTematica(String nomTematica) {
        return imub.visualitzarPelisPerTematica(nomTematica);
    }
    public Iterable<String> visualitzarSeriesPerNom() {
        return imub.visualitzarSeriesPerNom();
    }
    public Iterable<String> visualitzarTemporadesSerie(String nomSerie) {
        return imub.visualitzarTemporadesSerie(nomSerie);
    }
    public Iterable<String> visualitzaEpisodisTemporadaSerie(String nomSerie, int numTemporada) {
        return imub.visualitzaEpisodisTemporadaSerie(nomSerie, numTemporada);
    }


}
