package ub.edu.facade;

import ub.edu.model.ImUB;

public class FacadeValoracio {
    private ImUB imub;

    public FacadeValoracio(ImUB imub) {
        this.imub = imub;
    }

    public String visualitzarValoracioPelicula(String nomPelicula, String tipusValoracio, String tipusNumerica) {
        return imub.visualitzarValoracioPelicula(nomPelicula, tipusValoracio, tipusNumerica);
    }

    public String visualitzarValoracioEpisodi(String nomSerie, int numTemporada, int numEpisodi, String tipusValoracio, String tipusNumerica) {
        return imub.visualitzarValoracioEpisodi(nomSerie, numTemporada, numEpisodi, tipusValoracio, tipusNumerica);
    }
    public String visualitzarValoracioTemporada(String nomSerie, int numTemporada, String tipusValoracio, String tipusNumerica) {
        return imub.visualitzarValoracioTemporada(nomSerie, numTemporada, tipusValoracio, tipusNumerica);
    }
    public String visualitzarValoracioSerie(String nomSerie, String tipusValoracio, String tipusNumerica) {
        return imub.visualitzarValoracioSerie(nomSerie, tipusValoracio, tipusNumerica);
    }
    public String valorarPelicula(String nomPeli, String user, int puntuacio, String tipusValoracio){
        return imub.valorarPelicula(nomPeli, user, puntuacio, tipusValoracio);
    }
    public String valorarEpisodi(String nomSerie, int numTemporada, int numEpisodi, String user, int puntuacio, String tipusValoracio){
        return imub.valorarEpisodi(nomSerie, numTemporada, numEpisodi, user, puntuacio, tipusValoracio);
    }
    public String visualitzarTop5Pelicules(String tipusValoracio, String tipusNumerica){
        return imub.visualitzarTop5Pelicules(tipusValoracio, tipusNumerica);
    }
    public String visualitzarTop5Series(String tipusValoracio, String tipusNumerica){
        return imub.visualitzarTop5Series(tipusValoracio, tipusNumerica);
    }
}
