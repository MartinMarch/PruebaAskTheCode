package ub.edu.facade;

import ub.edu.model.*;

public class FacadeComunitat {
    private ImUB imub;

    public FacadeComunitat(ImUB imub) {
        this.imub = imub;
    }

    public void afegirComunitat(String nom, String descripcio){
        Comunitat comunitat = new Comunitat(nom, descripcio);
        imub.afegirComunitat(nom, comunitat);
    }
    public String afegirseComunitat(String nom, String descripcio) throws ImUBException {
        return imub.afegirseComunitat(nom, descripcio);
    }
    public String esborrarseComunitat(String user, String nomComunitat) throws ImUBException {
        Client client = imub.getClient(user);
        Comunitat comunitat = client.getComunitat(nomComunitat);
        if (comunitat == null){
            throw new ImUBException("No estàs afegit a aquesta comunitat");
        }
        client.esborrarComunitat(comunitat);
        return "Vostè ja no és membre de la comunitat";
    }
    public Iterable<String> visualitzarCommunityList(String user, String nomComunitat) throws ImUBException {
        Client client = imub.getClient(user);
        Comunitat comunitat = client.getComunitat(nomComunitat);
        if (comunitat == null){
            throw new ImUBException("Necessites pertànyer a la comunitat per poder veure'n el contingut");
        }
        GestorCommunityList gestorCommunityList = new GestorCommunityList(comunitat);
        return gestorCommunityList.visualitzarCommunityList();
    }


}
