package ub.edu.facade;

import ub.edu.model.*;
import ub.edu.resources.dao.Parell;
import ub.edu.resources.service.AbstractFactoryData;
import ub.edu.resources.service.DataService;
import ub.edu.resources.service.FactoryMOCK;

import java.util.List;

public class FacadeData {
    private ImUB imub;
    private AbstractFactoryData factory;
    private DataService dataService;

    public FacadeData(ImUB imub) {
        this.imub = imub;
        factory = new FactoryMOCK();
        dataService = new DataService(factory);
    }

    public void load() throws ImUBException{
        loadCarteraClients();
        loadPelicules();
        loadSeries();
        loadTematiques();
        loadComunitats();
        relacionarPeliculesTemes();
        relacionarSeriesTemes();
        relacionarComunitatsTemes();
    }

    /*-----------------------------*/
    /*  Cargar datos  */
    /*-----------------------------*/
    private void loadCarteraClients() throws ImUBException {
        List<Client> l = null;
        try {
            l = dataService.getAllPersones();
        } catch (Exception e) {
            throw new ImUBException("Error al cargar la cartera de clients");
        }
        imub.loadCarteraClients(l);
    }
    private void loadPelicules() throws ImUBException {
        List<Pelicula> l = null;
        try {
            l = dataService.getAllPelicules();
        } catch (Exception e) {
            throw new ImUBException("Error al cargar la llista de pelicules");
        }
        imub.loadPelicules(l);
    }
    private void loadSeries() throws ImUBException {
        List<Serie> l = null;
        try {
            l = dataService.getAllSeries();
        } catch (Exception e) {
            throw new ImUBException("Error al cargar la llista de series");
        }
        imub.loadSeries(l);
    }
    private void loadTematiques() throws ImUBException {
        List<Tematica> l = null;
        try {
            l = dataService.getAllTematiques();
        } catch (Exception e) {
            throw new ImUBException("Error al cargar la llista de tematiques");
        }
        imub.loadTematiques(l);
    }
    private void loadComunitats() throws ImUBException {
        List<Comunitat> l = null;
        try {
            l = dataService.getAllComunitats();
        } catch (Exception e) {
            throw new ImUBException("Error al cargar la llista de comunitats");
        }
        imub.loadComunitats(l);
    }

    /*-----------------------------*/
    /*  Relacionar contenido  */
    /*-----------------------------*/
    private void relacionarPeliculesTemes() {
        List<Parell<String, String>> relacionsPT = dataService.getAllRelacionsPeliculesTematiques();
        imub.relacionarPeliculesTemes(relacionsPT);
    }
    private void relacionarSeriesTemes() {
        List<Parell<String, String>> relacionsST = dataService.getAllRelacionsSeriesTematiques();
        imub.relacionarSeriesTemes(relacionsST);
    }
    private void relacionarComunitatsTemes() throws ImUBException {
        List<Parell<String, String>> relacionsCT = dataService.getAllRelacionsComunitatsTematiques();
        imub.relacionarComunitatsTemes(relacionsCT);
    }


    public DataService getDataService() {
        return dataService;
    }
}

