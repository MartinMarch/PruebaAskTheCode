# p2-imUB-DAO
Codi base de la pràctica 2: curs  23-24

